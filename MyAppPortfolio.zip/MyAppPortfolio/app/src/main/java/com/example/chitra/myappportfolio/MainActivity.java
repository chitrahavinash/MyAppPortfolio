package com.example.chitra.myappportfolio;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView txtTitle = (TextView) findViewById(R.id.txtTitle);
        Button btnPopularMovies = (Button) findViewById(R.id.btnPopularMovies);
        Button btnStockHawk = (Button) findViewById(R.id.btnStockHawk);
        Button btnBuildItBigger = (Button) findViewById(R.id.btnBuildItBigger);
        Button btnGoUbiquitos = (Button) findViewById(R.id.btnGoUbiquitos);
        Button btnCapStone = (Button) findViewById(R.id.btnCapStone);
        Button btnMakeYourAppMaterial = (Button) findViewById(R.id.btnMakeYourAppMaterial);

        txtTitle.setTextSize(16);
        btnPopularMovies.setTextSize(16);
        btnStockHawk.setTextSize(16);
        btnBuildItBigger.setTextSize(16);
        btnGoUbiquitos.setTextSize(16);
        btnCapStone.setTextSize(16);
        btnMakeYourAppMaterial.setTextSize(16);

        btnPopularMovies.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toastCall("This Button will launch my Popular Movies App!");
            }
        });

        btnStockHawk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toastCall("This Button will launch my Stock Hawk App!");
            }
        });

        btnBuildItBigger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toastCall("This Button will launch my Build It Bigger App!");
            }
        });

        btnGoUbiquitos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toastCall("This Button will launch my Go Ubiquitos App!");
            }
        });

        btnCapStone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toastCall("This Button will launch my Capstone App!");
            }
        });

        btnMakeYourAppMaterial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toastCall("This Button will launch my Make Your App Material App!");
            }
        });
    }


    private void toastCall(CharSequence Msg){
        LayoutInflater inflater = getLayoutInflater();

        View toastView = inflater.inflate(R.layout.custom_toast, null);
        Toast toast = new Toast(getApplicationContext());
        toast.setView(toastView);

        TextView txtView = (TextView) toastView.findViewById(R.id.toastCustom);
        txtView.setText(Msg);
        txtView.setGravity(Gravity.CENTER);

       // toast.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL,
             //   0, 0);

        //toast.setText(Msg);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.show();
        //Toast.makeText(getApplicationContext(), Msg, Toast.LENGTH_SHORT).show();


    }
}
